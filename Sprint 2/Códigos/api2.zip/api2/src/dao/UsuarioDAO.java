/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import com.mysql.cj.protocol.Resultset;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.Usuario;

/**
 *
 * @author gabri
 */
public class UsuarioDAO {
    private Connection conneciton;
    
    public UsuarioDAO(){
        this.conneciton = new ConnectionFactory().getConnection();
        } 
    public void adiciona(Usuario usuarios){
        String sql = "INSERT INTO usuarios (nome,nome_empresa,cargo,email,idperfil,projetos, senha) VALUE(?,?,?,?,?,?,?)";
        
        try{
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1,usuarios.getNome());
            stmt.setString(2,usuarios.getNome_empresa());
            stmt.setString(3,usuarios.getCargo());
            stmt.setString(4,usuarios.getEmail());
            stmt.setInt(5,usuarios.getId_perfil());
            stmt.setString(6,usuarios.getProjetos());
            stmt.setString(7,usuarios.getSenha());
            stmt.execute();
            stmt.close();
        }
        catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
    
    public ResultSet Autenticacao(Usuario usuario){
        String sql = "Select * from usuarios where email = ? and senha = ?";
        try{ 
             PreparedStatement stmt = conneciton.prepareStatement(sql);
             stmt.setString(1,usuario.getEmail());
             stmt.setString(2,usuario.getSenha());
             
             ResultSet rs = stmt.executeQuery();
             
        
             
            return rs;
        }catch (SQLException erro) {
           JOptionPane.showMessageDialog(null, "UsuarioDAO:" + erro);
           return null;
        }
    }
}
