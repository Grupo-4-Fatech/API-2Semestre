/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author gabri
 */
public class ChatDAO {

    private Connection conneciton;

    public ChatDAO() {
        this.conneciton = new ConnectionFactory().getConnection();
    }

    public Integer criarChat(String emailRemetente, String emailDestinatario) {
        String sql = "insert into chat (idchat) values (null)";

        try {
            Integer idchat = buscarChat(emailRemetente, emailDestinatario);
            if (idchat != null) {
                return idchat;
            }
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.execute();
            stmt.close();
            stmt = conneciton.prepareStatement("select idchat from chat order by 1 desc limit 1");
            ResultSet rs = stmt.executeQuery();
            rs.next();
            idchat = rs.getInt(1);
             stmt = conneciton.prepareStatement("insert into chat_usuario(idchat, email) values(?,?),(?,?)");
            stmt.setString(1, idchat.toString());
            stmt.setString(2, emailRemetente);
            stmt.setString(3, idchat.toString());
            stmt.setString(4, emailDestinatario);
            stmt.execute();
            stmt.close();
            
            return idchat;
            

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public Integer buscarChat(String emailRemetente, String emailDestinatario) {
        String sql = "SELECT idchat from chat_usuario where idchat in (SELECT idchat from chat_usuario where email = ?) and email = ?";

        try {
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1, emailRemetente);
            stmt.setString(2, emailDestinatario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("idchat");
            }
            return null;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

}
