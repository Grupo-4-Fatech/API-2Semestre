/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author gabri
 */
public class ConsultaDAO {
     private Connection conneciton; 
      public ConsultaDAO(){
        this.conneciton= new ConnectionFactory().getConnection();
    }
   public  ResultSet carregarTabela(){
       String sql = "SELECT email, texto FROM cadastrar_mensagem";
       
      try {
           PreparedStatement stmt = conneciton.prepareStatement(sql);
           ResultSet rs = stmt.executeQuery(sql);
                return rs;
           
       } catch (SQLException u) {
           throw new RuntimeException(u);
       }
       
        
        
    }
    
}
