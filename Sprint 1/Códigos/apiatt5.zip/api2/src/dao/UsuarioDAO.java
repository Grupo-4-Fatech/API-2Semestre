/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Usuario;

/**
 *
 * @author gabri
 */
public class UsuarioDAO {
    private Connection conneciton;
    
    public UsuarioDAO(){
        this.conneciton = new ConnectionFactory().getConnection();
        } 
    public void adiciona(Usuario usuarios){
        String sql = "INSERT INTO usuarios (nome,nome_empresa,cargo,email,idperfil,projetos) VALUE(?,?,?,?,?,?)";
        
        try{
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1,usuarios.getNome());
            stmt.setString(2,usuarios.getNome_empresa());
            stmt.setString(3,usuarios.getCargo());
            stmt.setString(4,usuarios.getEmail());
            stmt.setInt(5,usuarios.getId_perfil());
            stmt.setString(6,usuarios.getProjetos());
            stmt.execute();
            stmt.close();
        }
        catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
}
