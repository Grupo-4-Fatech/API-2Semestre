/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import modelo.Mensagens;


/**
 *
 * @author Marcelo
 */
public class msgDAO {
    private Connection conneciton; 
    
    public msgDAO(){
        this.conneciton= new ConnectionFactory().getConnection();
    }
    public void adiciona(Mensagens mensagen){
        
        String sql= "INSERT INTO  cadastrar_mensagem(idtipo_mensagem,texto,email) VALUE(?,?,?)";
       
        try {
          PreparedStatement stmt = conneciton.prepareStatement(sql);
          stmt.setInt(1,mensagen.getId_tipo_mensagem());
          stmt.setString(2, mensagen.getTexto());
          stmt.setString(3,mensagen.getEmail());
          stmt.execute();
          stmt.close();
          
            
        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        
        
    }
    
    
    
}
