/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Date;

/**
 *
 * @author Marcelo
 */
public class Mensagens {
   private int idmensagem;
   private int id_tipo_mensagem;
   private String texto;
   private String email;
  

    public int getIdmensagem() {
        return idmensagem;
    }

    public void setIdmensagem(int idmensagem) {
        this.idmensagem = idmensagem;
    }
        
    public int getId_tipo_mensagem() {
        return id_tipo_mensagem;
    }

    public void setId_tipo_mensagem(int id_tipo_mensagem) {
        this.id_tipo_mensagem = id_tipo_mensagem;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

   
    
}
