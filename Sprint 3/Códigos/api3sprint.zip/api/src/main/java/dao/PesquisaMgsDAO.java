/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Mensagens;
import modelo.Usuario;

/**
 *
 * @author SAMUEL
 *////Mensagens mensagen
public class PesquisaMgsDAO {  
    private final Connection conneciton;
     Mensagens mensagen= new Mensagens();
        

     
    public PesquisaMgsDAO(){
        this.conneciton = new ConnectionFactory().getConnection();
        } 
    public boolean pesquisa(Mensagens mensagen) throws SQLException{
        String Email = mensagen.getEmail();
        String sql = "SELECT * FROM cadastrar_mensagem where Email = ?";
         PreparedStatement stmt = conneciton.prepareStatement(sql);
         stmt.setString(1,Email);
         
         ResultSet rs = stmt.executeQuery();
         if (rs.next()){
           mensagen.setEmail(rs.getString("Email"));
           mensagen.setIdmensagem(rs.getInt("Id_cadastrar_mensagem"));
           mensagen.setTexto(rs.getString("Texto"));
           mensagen.setTipo_mensagem(rs.getString("Tipo_mensagem"));
           
           
           
         }
           
        return true;
    }
    
     
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
