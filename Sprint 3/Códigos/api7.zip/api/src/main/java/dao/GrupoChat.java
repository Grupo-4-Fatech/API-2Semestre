/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import chat.Chat;
import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Vector;
import javax.swing.*;
import javax.swing.border.*;
import modelo.Usuario;

public class GrupoChat extends JFrame {
    

    JList lista;
    private JDesktopPane painel;
    private Usuario usuarioLogado;
    private JTextField nome;

    public GrupoChat(Usuario usuario) {
        super("Grupo chat");
        usuarioLogado = usuario;
        
        
        Container c = getContentPane();
        c.setLayout(new FlowLayout(FlowLayout.LEFT));

        // Cria a JList
        lista = new JList();

        // Define o renderizador de células
        lista.setCellRenderer(new CheckBoxCellRenderer());

        List<String> emails = new UsuarioDAO().BuscarUsuario();
        Vector<JCheckBox> checkBox = new Vector<>();

        for (String email : emails) {
            checkBox.add(new JCheckBox(email));
        }

        // Define os valores da lista
//  
        // Atribue os itens à lista
        lista.setListData(checkBox);
        // Define a seleção única para a lista
        lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Aqui nós permitimos que as checkboxes sejam marcadas
        // ou desmarcadas com a barra de espaço
        lista.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    int index = lista.getSelectedIndex();
                    if (index != -1) {
                        JCheckBox checkbox
                                = (JCheckBox) lista.getModel().getElementAt(index);
                        checkbox.setSelected(!checkbox.isSelected());
                        repaint();
                    }
                }
            }
        });

        // Aqui nós permitimos que as checkboxes sejam marcadas
        // ou desmarcadas com o mouse
        lista.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                int index = lista.locationToIndex(e.getPoint());
                if (index != -1) {
                    JCheckBox checkbox
                            = (JCheckBox) lista.getModel().getElementAt(index);
                    checkbox.setSelected(!checkbox.isSelected());
                    repaint();
                }
            }
        });

        // Um botão que permite obter os itens marcados
        JButton btn = new JButton("Criar grupo");
        btn.addActionListener(
                new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String nomeGrupo = nome.getText().trim();
                
                ArrayList<String> ListaEmails = new ArrayList<>();
                for (int i = 0; i < lista.getModel().getSize(); i++) {
                    JCheckBox checkbox = (JCheckBox) lista.getModel().getElementAt(i);
                    if (checkbox.isSelected()) {
                        ListaEmails.add(checkbox.getText());
                    }
                }
                if (!nomeGrupo.isEmpty() && !ListaEmails.isEmpty()){
                    ListaEmails.add(usuarioLogado.getEmail());
                    ChatDAO chatDAO = new ChatDAO();
                    Integer idchat = chatDAO.criarChatGrupo(nomeGrupo);
                    Integer idgrupo = chatDAO.criarGrupo(idchat, nomeGrupo);
                    chatDAO.insertGrupo(idgrupo, ListaEmails);
                    chatDAO.insertUsuChat(idchat, ListaEmails);
                        JOptionPane.showMessageDialog(null, "Grupo criado com sucesso!");
                    setVisible(false);
                    dispose();
                }
            }
        });

        // Adiciona a lista à janela
        c.add(new JScrollPane(lista));

        // Adiciona o botão à janela
        c.add(btn);

        // Adciona o campo de texto para adicionar o nome do grupo
        nome = new JTextField(10);

        nome.setText("");

        add(nome);

        setSize(600, 400);
        pack();
        setVisible(true);

    }

    
}

// Classe personalizada que permite que os itens
// da lista sejam exibidos como JCheckBoxes
class CheckBoxCellRenderer implements ListCellRenderer {

    Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);

    public Component getListCellRendererComponent(
            JList list, Object value, int index,
            boolean isSelected, boolean cellHasFocus) {
        JCheckBox checkbox = (JCheckBox) value;
        checkbox.setBackground(isSelected
                ? list.getSelectionBackground() : list.getBackground());
        checkbox.setForeground(isSelected
                ? list.getSelectionForeground() : list.getForeground());

        checkbox.setEnabled(list.isEnabled());
        checkbox.setFont(list.getFont());
        checkbox.setFocusPainted(false);

        checkbox.setBorderPainted(true);
        checkbox.setBorder(isSelected ? UIManager.getBorder(
                "List.focusCellHighlightBorder") : noFocusBorder);

        return checkbox;
    }

}
