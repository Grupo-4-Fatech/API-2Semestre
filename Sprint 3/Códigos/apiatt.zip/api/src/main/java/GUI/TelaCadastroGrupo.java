/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package GUI;

import java.awt.Container;
import java.awt.FlowLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JCheckBox;
import javax.swing.JDesktopPane;
import javax.swing.JList;
import javax.swing.JOptionPane;
import modelo.Usuario;

/**
 *
 * @author gabri
 */
public class TelaCadastroGrupo extends javax.swing.JInternalFrame {
//    JList lista;  
// 
//  public TelaCadastroGrupo() {
//    super("A classe JList");
//     
//    Container c = getContentPane();
//    c.setLayout(new FlowLayout(FlowLayout.LEFT));
// 
//    // Cria a JList
//    lista = new JList();
// 
//    // Define o renderizador de células
//    lista.setCellRenderer(new CheckBoxCellRenderer());
// 
//    
//    // Define os valores da lista
//    Object[] cbArray = new Object[4];
//    cbArray[0] = new JCheckBox("Goiânia");
//    cbArray[1] = new JCheckBox("Brasília");
//    cbArray[2] = new JCheckBox("Barra do Garças");
//    cbArray[3] = new JCheckBox("Curitiba");
//  
//    // Atribue os itens à lista
//    lista.setListData(cbArray);
//     
//    // Define a seleção única para a lista
//    lista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
// 
//    // Aqui nós permitimos que as checkboxes sejam marcadas
//    // ou desmarcadas com a barra de espaço
//    lista.addKeyListener(new KeyAdapter(){
//      public void keyPressed(KeyEvent e){
//        if(e.getKeyCode() == KeyEvent.VK_SPACE){
//          int index = lista.getSelectedIndex();
//          if(index != -1){
//            JCheckBox checkbox = 
//              (JCheckBox) lista.getModel().getElementAt(index);
//            checkbox.setSelected(!checkbox.isSelected());
//            repaint();
//          }
//        }
//      }
//    });
// 
//    // Aqui nós permitimos que as checkboxes sejam marcadas
//    // ou desmarcadas com o mouse
//    lista.addMouseListener(new MouseAdapter(){
//      public void mousePressed(MouseEvent e){
//        int index = lista.locationToIndex(e.getPoint());
//        if(index != -1){
//          JCheckBox checkbox = 
//            (JCheckBox) lista.getModel().getElementAt(index);
//          checkbox.setSelected(!checkbox.isSelected());
//          repaint();
//        }
//      }
//    });
// 
//    // Um botão que permite obter os itens marcados
//    JButton btn = new JButton("Obter itens marcados");
//    btn.addActionListener(
//      new ActionListener(){
//        public void actionPerformed(ActionEvent e){
//          String itens = "";
// 
//          for(int i = 0; i < lista.getModel().getSize(); i++){
//            JCheckBox checkbox = 
//                (JCheckBox) lista.getModel().getElementAt(i);
//              if(checkbox.isSelected())
//                itens += "Item com índice " + i + 
//                  " está marcado\n";
//              else
//                itens += "Item com índice " + i + 
//                  " está desmarcado\n";
//          }          
// 
//          JOptionPane.showMessageDialog(null, 
//            itens);
//        }
//      }
//    );
// 
//    // Adiciona a lista à janela
//    c.add(new JScrollPane(lista));
// 
//    // Adiciona o botão à janela
//    c.add(btn);  
// 
//    setSize(350, 250);
//    setVisible(true);
//  }
//   
//  public static void main(String args[]){
//    Estudos app = new Estudos();
//    app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//  }
//}
// 
//// Classe personalizada que permite que os itens
//// da lista sejam exibidos como JCheckBoxes
//class CheckBoxCellRenderer implements ListCellRenderer{
//  Border noFocusBorder = new EmptyBorder(1, 1, 1, 1);  
// 
//  public Component getListCellRendererComponent(
//       JList list, Object value, int index,
//       boolean isSelected, boolean cellHasFocus){
//    JCheckBox checkbox = (JCheckBox) value;
//    checkbox.setBackground(isSelected ? 
//      list.getSelectionBackground() : list.getBackground());
//    checkbox.setForeground(isSelected ? 
//      list.getSelectionForeground() : list.getForeground());
//  
//    checkbox.setEnabled(list.isEnabled());
//    checkbox.setFont(list.getFont());
//    checkbox.setFocusPainted(false);
//  
//    checkbox.setBorderPainted(true);
//    checkbox.setBorder(isSelected ? UIManager.getBorder(
//       "List.focusCellHighlightBorder") : noFocusBorder);
//  
//    return checkbox;
//  }
//}

//    private JDesktopPane painel;
//    private Usuario usuarioLogado;
//    /**
//     * Creates new form TelaCadastroGrupo
//     */
//    public TelaCadastroGrupo() {
//        initComponents();
//        this.painel = painel;
//        this.usuarioLogado = usuarioLogado;
//        
//       
//        
//    }

//    public List<Usuario> BuscarUsuario() throws SQLException{
//        List<Usuario> usuarios= new ArrayList<>();
//        String sql = "select * from usuarios ";
//        int coluna = 1;
//        try {
//            Connection con = DriverManager.getConnection("jdbc:mysql://bd-api.mysql.database.azure.com:3306/bd_api?user=adminfatech&password=Fatecsjc123");
//            PreparedStatement stmt = con.prepareStatement(sql);
//            con = rs.prepareStatement(sql);
//            rs = con.executeQuery();
//            while (rs.next())
//            {            
//                usuarios.add(rs.getString(1)+";"+rs.getString(2)+";"+rs.getString(3)+";"+rs.getString(4)+";"+rs.getString(5)+";"+rs.getString(6)+";"+rs.getString(7)+";"+rs.getString(8));                
//            }
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, e);
//        }
//        for(String str : dados){
//            System.out.println(str);
//        }
//}
//   public List<Usuario> BuscarUsuario(){
//    List<String> usuarios = new ArrayList<String>(); //Lista que vai receber todos os registros da sua query
//    String resultado = null;
//    String sql = "SELECT * FROM USUARIOS";
//    try {
//        Connection con = DriverManager.getConnection("jdbc:mysql://bd-api.mysql.database.azure.com:3306/bd_api?user=adminfatech&password=Fatecsjc123");
//	PreparedStatement pst = con.prepareStatement(sql);
//	ResultSet rs = pst.executeQuery();
//	while(rs.next()) { //use o while ao invés de if.. "enquanto" tiver proximo registro..
//		resultado = (rs.getString(1)+";" + 
//						rs.getString(2)+";" + 
//						rs.getString(3)+";" + 
//						rs.getString(4)+";" + 
//						rs.getString(5)+";" + 
//						rs.getString(6)+";" + 
//						rs.getString(7)+";" + 
//						rs.getString(8));
//		usuarios.add(resultado); //adiciona o usuario encontrado na lista
//                
//         while(rs.next()){
//             usuarios = (List<String>) new JCheckBox();
//         }       
//        }
//        
//    } catch (SQLException e) {
//	JOptionPane.showMessageDialog(null, e);
//    }
//
//    //imprime todos os resultados
//    for(String r : usuarios) {
//	System.out.println(r);
//    }
//        return null;
//} 
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton1 = new javax.swing.JButton();

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(143, 143, 143)
                .addComponent(jButton1)
                .addContainerGap(157, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(75, 75, 75)
                .addComponent(jButton1)
                .addContainerGap(170, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
       
        
        
    }//GEN-LAST:event_jButton1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
