package chat;

import javax.swing.JTextPane;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

public class ChatMessage extends JTextPane {

    private static final long serialVersionUID = 1L;
    private Color borderColor = Color.BLUE;

    public Color getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(Color borderColor) {
        this.borderColor = borderColor;
    }

    public Color getBgColor() {
        return bgColor;
    }

    public void setBgColor(Color bgColor) {
        this.bgColor = bgColor;
    }
    private Color bgColor = Color.GREEN;

    public ChatMessage() {
        setBackground(new Color(0, 0, 0, 0));
    }

    @Override
    protected void paintComponent(Graphics graphics) {
        Graphics2D graphics2d = (Graphics2D) graphics;
        graphics2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        graphics2d.setColor(bgColor);
        graphics2d.fillRoundRect(0, 0, getWidth(), getHeight(), 5, 5);
        graphics2d.setColor(borderColor);
        graphics2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 5, 5);
        super.paintComponent(graphics);
    }

}
