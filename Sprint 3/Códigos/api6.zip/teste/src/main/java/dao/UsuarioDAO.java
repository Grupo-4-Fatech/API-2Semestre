/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.Usuario;

/**
 *
 * @author gabri
 */
public class UsuarioDAO {
    private Connection conneciton;
    
    public UsuarioDAO(){
        this.conneciton = new ConnectionFactory().getConnection();
        } 
    public void adiciona(Usuario usuarios){
        String sql = "INSERT INTO usuarios (nome,nome_empresa,cargo,email,idperfil,projetos, senha) VALUE(?,?,?,?,?,?,?)";
        
        try{
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1,usuarios.getNome());
            stmt.setString(2,usuarios.getNome_empresa());
            stmt.setString(3,usuarios.getCargo());
            stmt.setString(4,usuarios.getEmail());
            stmt.setInt(5,usuarios.getId_perfil());
            stmt.setString(6,usuarios.getProjetos());
            stmt.setString(7,usuarios.getSenha());
            stmt.execute();
            stmt.close();
        }
        catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
    
    public ResultSet Autenticacao(Usuario usuario){
        String sql = "Select * from usuarios where email = ? and senha = ?";
        try{ 
             PreparedStatement stmt = conneciton.prepareStatement(sql);
             stmt.setString(1,usuario.getEmail());
             stmt.setString(2,usuario.getSenha());
             
             ResultSet rs = stmt.executeQuery();
             
        
             
            return rs;
        }catch (SQLException erro) {
           JOptionPane.showMessageDialog(null, "UsuarioDAO:" + erro);
           return null;
        }
    }
       
    public ResultSet seleciona (Usuario usuario){
        String sql = "Select * from usuarios where email != ? ";
        
        try{ 
             PreparedStatement stmt = conneciton.prepareStatement(sql);
             stmt.setString(1,usuario.getEmail());
                        
             ResultSet rs = stmt.executeQuery();
             
        
             
            return rs;
        }catch (SQLException erro) {
           JOptionPane.showMessageDialog(null, "UsuarioDAO:" + erro);
           return null;
        }
        
    }
    public boolean alterar(Usuario usuario){
        int registros;
                
        String sql = "update usuarios set Nome =?, Nome_empresa =?, Cargo =?, Projetos =?, senha =? where Email =? ";
        
        try{
            PreparedStatement stmt = conneciton.prepareStatement(sql);            

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getNome_empresa());
            stmt.setString(3, usuario.getCargo());
            stmt.setString(4, usuario.getProjetos());
            stmt.setString(5,usuario.getSenha());
            stmt.setString(6, usuario.getEmail());
            registros = stmt.executeUpdate();
            if ( registros == 1){
                return false ; }
            else { 
                return false ; }
        }
        catch (SQLException u) {
            throw new RuntimeException(u);
        }       
    }//final do alterar
    
    
    public List<String> BuscarUsuario(){
    List<String> usuarios = new ArrayList<String>(); //Lista que vai receber todos os registros da sua query
    String resultado = null;
    String sql = "SELECT email FROM USUARIOS";
    try {
        Connection con = DriverManager.getConnection("jdbc:mysql://bd-api.mysql.database.azure.com:3306/bd_api?user=adminfatech&password=Fatecsjc123");
	PreparedStatement pst = con.prepareStatement(sql);
	ResultSet rs = pst.executeQuery();
	while(rs.next()) { //use o while ao invés de if.. "enquanto" tiver proximo registro..
		resultado = rs.getString(1);
		usuarios.add(resultado); //adiciona o usuario encontrado na lista
                
               
        }
        
    } catch (SQLException e) {
	JOptionPane.showMessageDialog(null, e);
    }

    //imprime todos os resultados
    for(String r : usuarios) {
	System.out.println(r);
    }
        return usuarios;
} 
}
