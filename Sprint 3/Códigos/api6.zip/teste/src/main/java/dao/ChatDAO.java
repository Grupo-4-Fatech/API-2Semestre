/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import chat.Chat;
import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.ChatModel;
import modelo.Usuario;

/**
 *
 * @author gabri
 */
public class ChatDAO {

    private Connection conneciton;

    public ChatDAO() {
        this.conneciton = new ConnectionFactory().getConnection();
    }

    public Integer criarChat(String emailRemetente, String emailDestinatario) {
        String sql = "insert into chat (idchat, titulo) values (null,\"\")";
        Integer idchat;
        try {
//            Integer idchat = buscarChat(emailRemetente, emailDestinatario);
//            if (idchat != null) {
//                return idchat;
//            }
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.execute();
            stmt.close();
            stmt = conneciton.prepareStatement("select idchat from chat order by 1 desc limit 1");
            ResultSet rs = stmt.executeQuery();
            rs.next();
            idchat = rs.getInt(1);
            stmt = conneciton.prepareStatement("insert into chat_usuario(idchat, email) values(?,?),(?,?)");
            stmt.setString(1, idchat.toString());
            stmt.setString(2, emailRemetente);
            stmt.setString(3, idchat.toString());
            stmt.setString(4, emailDestinatario);
            stmt.execute();
            stmt.close();

            return idchat;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public Integer criarChatGrupo(String titulo) {
        String sql = "insert into chat (idchat,titulo) values (null,?)";
        try {
            
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1,titulo);
            stmt.execute();
            stmt.close();
            stmt = conneciton.prepareStatement("select idchat from chat order by 1 desc limit 1");
            ResultSet rs = stmt.executeQuery();
            rs.next();
            return rs.getInt("idchat");

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public Integer criarGrupo(Integer idchat, String nome) {
        String sql = "insert into grupo (idchat, nome) values (?,?)";

        try {
            Integer idgrupo = buscarChatGrupo(idchat, nome);
            if (idgrupo != null) {
                return idgrupo;
            }
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1, idchat.toString());
            stmt.setString(2, nome);
            stmt.execute();
            stmt.close();
            stmt = conneciton.prepareStatement("select idgrupo from grupo order by 1 desc limit 1");
            ResultSet rs = stmt.executeQuery();
            rs.next();
            idgrupo = rs.getInt(1);

            return idgrupo;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public void insertGrupo(Integer idgrupo, List<String> emails) {
        String sql = "insert into grupo_usuario (idgrupo,email) values ";

        try {
            for (String email : emails) {
                sql = sql + "(?,?),";
            }
            sql = sql.substring(0,sql.length()-1);  
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            for (int i = 0; i < emails.size(); i++) {
                stmt.setString(i*2+1, idgrupo.toString());
                stmt.setString(i*2+2, emails.get(i));

            }           
            stmt.execute();
            stmt.close();
    

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
        // inserindo usuario dos grupos no chat_usuario
       public void insertUsuChat(Integer idchat, List<String> emails) {
        String sql = "insert into chat_usuario (idchat,email) values ";

        try {
            for (String email : emails) {
                sql = sql + "(?,?),";
            }
            sql = sql.substring(0,sql.length()-1);  
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            for (int i = 0; i < emails.size(); i++) {
                stmt.setString(i*2+1, idchat.toString());
                stmt.setString(i*2+2, emails.get(i));

            }           
            stmt.execute();
            stmt.close();
    

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
    
    public Integer buscarChat(String emailRemetente, String emailDestinatario) {
        String sql = "SELECT idchat from chat_usuario where idchat in (SELECT idchat from chat_usuario where email = ?) and email = ?";

        try {
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1, emailRemetente);
            stmt.setString(2, emailDestinatario);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("idchat");
            }
            return null;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public Integer buscarChatGrupo(Integer idchat, String nome) {
        String sql = "SELECT idgrupo from grupo_usuario where idgrupo in (SELECT idgrupo from grupo_usuario where email = ?) and email = ?";

        try {
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1, idchat.toString());
            stmt.setString(2, nome);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("idgrupo");
            }
            return null;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }

    public List<ChatModel> buscarChatsUsu(Usuario usuario){
        String sql = "select c.* from chat c join chat_usuario chatU on (c.idchat = chatU.idchat) where chatU.email = ? and c.titulo <> \"\" ";
        String sql2 = "select chatu.* from chat c join chat_usuario chatu on(c.idchat = chatu.idchat) where c.titulo = \"\" and c.idchat in (select idchat from chat_usuario where email = ? ) and chatu.email != ?";
        try {
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1, usuario.getEmail());
            ResultSet rs = stmt.executeQuery();
            ArrayList<ChatModel> listaChats = new ArrayList<>();
            while (rs.next()) {
                listaChats.add(new ChatModel(rs.getInt(1), rs.getString(2)));
            }
            stmt = conneciton.prepareStatement(sql2);
            stmt.setString(1, usuario.getEmail());
            stmt.setString(2, usuario.getEmail());
            rs = stmt.executeQuery();  
            while (rs.next()) {
                listaChats.add(new ChatModel(rs.getInt(1), rs.getString(2)));
            }
            return listaChats;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
        
    }
    
    public List<String> semChat(Usuario usuario){
        String sql = "select email from usuarios where email not in (select chatu.email from chat_usuario chatu where chatu.idchat in (select c.idchat from chat c join chat_usuario chatu on (chatu.idchat = c.idchat) where c.titulo = \"\" and chatu.email = ?) group by chatu.email);";
        try {
            PreparedStatement stmt = conneciton.prepareStatement(sql);
            stmt.setString(1, usuario.getEmail());           
            ResultSet rs = stmt.executeQuery();
            ArrayList<String> listaEmails = new ArrayList<>();
            while (rs.next()) {
                listaEmails.add(rs.getString(1));
            }
            return listaEmails;

        } catch (SQLException u) {
            throw new RuntimeException(u);
        }
    }
}
