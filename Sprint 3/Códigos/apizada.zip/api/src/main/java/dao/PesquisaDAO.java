/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import modelo.Usuario;

/**
 *
 * @author T-GAMER
 */
public class PesquisaDAO {
    private final Connection conneciton;
     Usuario usuario= new Usuario();
             
    public PesquisaDAO(){
        this.conneciton = new ConnectionFactory().getConnection();
        } 
    public boolean pesquisa(Usuario usuario) throws SQLException{
        String Email = usuario.getEmail();
        String sql = "SELECT * FROM usuarios where Email = ?";
         PreparedStatement stmt = conneciton.prepareStatement(sql);
         stmt.setString(1,Email);
         
         ResultSet rs = stmt.executeQuery();
         if (rs.next()){
           usuario.setNome(rs.getString("Nome"));
           usuario.setNome_empresa(rs.getString("Nome_empresa"));
           usuario.setCargo(rs.getString("Cargo"));
           usuario.setProjetos(rs.getString("Projetos"));
           usuario.setSenha(rs.getString("senha"));
           
         }
           
        return true;
    }
    
    
}
