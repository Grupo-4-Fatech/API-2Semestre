/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor;

import com.corundumstudio.socketio.listener.*;
import com.corundumstudio.socketio.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.json.JsonMapper;
import servidor.ChatMessagesModel;

public class ServerIO {

    public static void main(String args[]) throws InterruptedException {
        System.out.println("Starting server...");
        Configuration config = new Configuration();
        config.setHostname("localhost");
        config.setPort(9092);
        config.setTransports(new Transport[]{Transport.WEBSOCKET, Transport.POLLING});
        config.setOrigin("*");

        final SocketIOServer server = new SocketIOServer(config);
        
        server.addConnectListener(client -> {
            System.out.println ("server: "+ client.getRemoteAddress()+ " client connection success");
        });
        server.addDisconnectListener(client -> {
            String c= client.getRemoteAddress().toString();
            // get device IP
            String clientIp = c.substring(1, c.indexOf(":"));
            System.out.println ("server:"+clientIp+"-----------------------------------"+"client disconnected");
        });
        

        server.addEventListener("joinRoom", String.class, new DataListener<String>() {
            @Override
            public void onData(SocketIOClient client, String roomName, AckRequest ackRequest) {
                System.out.println("Joining in room: " + roomName);
                client.joinRoom(roomName);
            }
        });

        server.addEventListener("saveMessage", String.class, new DataListener<String>() {
            @Override
            public void onData(SocketIOClient client, String jsonMessage, AckRequest ackRequest) {
                
                ChatMessagesModel message = transform(jsonMessage);
                System.out.println("Message got in server: " + message.getMensagem().getTexto());
                System.out.println("Salvando mensagem no banco de dados...");
                server.getRoomOperations(message.getId().toString()).sendEvent("getNewMessage", message);
            }
        });

        System.out.println("Trully starting...");
     
        server.start();

        Thread.sleep(Integer.MAX_VALUE);

        server.stop();
    }
    
    private static ChatMessagesModel transform(String json) {
        try {
            return new JsonMapper().readValue(json, ChatMessagesModel.class);
        } catch (JsonProcessingException e) {
            System.out.println(e);
            System.out.println("Erro ao converter '"+json+"' to ChatMessagesModel");
            throw new RuntimeException("Erro ao desconverter", e);
        }
    }
}
