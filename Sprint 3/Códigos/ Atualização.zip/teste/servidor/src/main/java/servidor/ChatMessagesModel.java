/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor;



/**
 *
 * @author denis
 */
public class ChatMessagesModel {
    private Integer id;
    private Mensagens mensagem;

    public ChatMessagesModel() {}
    public ChatMessagesModel(Integer id, Mensagens mensagem) {
        this.id = id;
        this.mensagem = mensagem;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Mensagens getMensagem() {
        return mensagem;
    }

    public void setMensagem(Mensagens mensagem) {
        this.mensagem = mensagem;
    }
}
