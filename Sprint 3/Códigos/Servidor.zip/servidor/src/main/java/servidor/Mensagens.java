/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package servidor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.sql.Date;

/**
 *
 * @author Marcelo
 */
@JsonIgnoreProperties(value = {"remetente"})
public class Mensagens {
   private int idmensagem;
   private String tipo_mensagem;
   private String texto;
   private String email;
   private Integer id_chat;

    public Mensagens(int idmensagem, String tipo_mensagem, String texto, String email, Integer id_chat) {
        this.idmensagem = idmensagem;
        this.tipo_mensagem = tipo_mensagem;
        this.texto = texto;
        this.email = email;
        this.id_chat = id_chat;
    }

    public Integer getId_chat() {
        return id_chat;
    }

    public void setId_chat(Integer id_chat) {
        this.id_chat = id_chat;
    }

    public Mensagens() {
        
    }
  

    public int getIdmensagem() {
        return idmensagem;
    }

    public void setIdmensagem(int idmensagem) {
        this.idmensagem = idmensagem;
    }
        
    public String getTipo_mensagem() {
        return tipo_mensagem;
    }

    public void setTipo_mensagem(String tipo_mensagem) {
        this.tipo_mensagem = tipo_mensagem;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

   
    
}
